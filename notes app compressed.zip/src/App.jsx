import { useState, useEffect, useRef } from "react";
import "./App.css";

function App() {
  const [notes, setNotes] = useState(() => {
    return JSON.parse(localStorage.getItem("notes")) || [];
  });

  const [text, setText] = useState("");
  const [editIndex, setEditIndex] = useState(null);
  const inputRef = useRef(null);

  useEffect(() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);

  const addOrUpdateNote = () => {
    if (text.trim() === "") return;

    if (editIndex !== null) {
      const updatedNotes = [...notes];
      updatedNotes[editIndex] = text;
      setNotes(updatedNotes);
      setEditIndex(null);
    } else {
      setNotes([...notes, text]);
    }

    setText("");
    inputRef.current.focus();
  };

  const editNote = (index) => {
    setText(notes[index]);
    setEditIndex(index);
    inputRef.current.focus();
  };

  const deleteNote = (index) => {
    setNotes(notes.filter((_, i) => i !== index));
  };

  return (
    <div className="container">
      <h1>📝 Notes App</h1>

      <div className="input-box">
        <input
          ref={inputRef}
          type="text"
          placeholder="Write your note..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button onClick={addOrUpdateNote}>
          {editIndex !== null ? "Update" : "Add"}
        </button>
      </div>

      <ul className="notes-list">
        {notes.map((note, index) => (
          <li key={index}>
            <span>{note}</span>
            <div>
              <button className="edit" onClick={() => editNote(index)}>✏️</button>
              <button className="delete" onClick={() => deleteNote(index)}>🗑️</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
